from flask import Blueprint, render_template, request, flash, redirect, url_for, send_file
from services.forecast_service import process_forecast, run_demo
from utils.file_handler import save_uploaded_file

forecast_bp = Blueprint("forecast", __name__)

@forecast_bp.route('/')
def index():
    return render_template("index.html")

@forecast_bp.route('/upload', methods=['POST'])
def upload():
    file = request.files.get('file')
    if not file or file.filename == '':
        flash("No file selected.")
        return redirect(url_for('forecast.index'))

    filepath = save_uploaded_file(file)
    result_df, plot_html = process_forecast(filepath)
    result_df.to_csv("uploads/forecast_result.csv", index=False)
    return render_template("forecast.html", plot=plot_html, tables=[result_df.to_html(classes='table')])

@forecast_bp.route('/demo')
def demo():
    result_df, plot_html = run_demo()
    result_df.to_csv("uploads/forecast_result.csv", index=False)
    return render_template("forecast.html", plot=plot_html, tables=[result_df.to_html(classes='table')])

@forecast_bp.route('/download')
def download():
    return send_file("uploads/forecast_result.csv", as_attachment=True)
