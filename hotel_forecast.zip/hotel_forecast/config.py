class Config:
    UPLOAD_FOLDER = 'uploads/'
    SECRET_KEY = 'high_entropy_secret_key'
