from flask import Flask
from routes.forecast_route import forecast_bp
import os

app = Flask(__name__)
app.secret_key = "high_entropy_secret_key"
app.config['UPLOAD_FOLDER'] = 'uploads/'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

app.register_blueprint(forecast_bp)

if __name__ == '__main__':
    app.run(debug=True)
