import pandas as pd
from prophet import Prophet
import plotly.graph_objs as go
from plotly.offline import plot
import os

def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    df['date'] = pd.to_datetime(df['date'])
    df_grouped = df.groupby('date')['bookings'].sum().reset_index()
    df_grouped.columns = ['ds', 'y']
    return df_grouped

def generate_plot(actual_df: pd.DataFrame, forecast_df: pd.DataFrame) -> str:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=actual_df['ds'], y=actual_df['y'], name='Actual'))
    fig.add_trace(go.Scatter(x=forecast_df['ds'], y=forecast_df['yhat'], name='Forecast'))
    return plot(fig, output_type='div')

def process_forecast(filepath: str):
    df = pd.read_csv(filepath)
    data = preprocess(df)

    model = Prophet()
    model.fit(data)

    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)

    result = forecast[['ds', 'yhat']].tail(7).rename(columns={'ds': 'Date', 'yhat': 'Predicted_Bookings'})
    plot_html = generate_plot(data, forecast)

    return result, plot_html

def run_demo():
    demo_path = "data/hotel_booking_10000_random_dates.csv"
    if not os.path.exists(demo_path):
        raise FileNotFoundError(f"Demo dataset not found at {demo_path}")
    return process_forecast(demo_path)
